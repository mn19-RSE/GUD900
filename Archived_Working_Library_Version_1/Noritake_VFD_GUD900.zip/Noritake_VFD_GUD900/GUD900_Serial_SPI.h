#pragma once

#include <Arduino.h>
#include <SPI.h>
#include "GUD900_Interface.h"

// SPI command definitions
#define DATA_WRITE_CMD   0x44
#define DATA_READ_CMD    0x54
#define STATUS_READ_CMD  0x58

class GUD900_Serial_SPI : public GUD900_Interface {

protected:
    uint8_t _busyPin;
    uint8_t _resetPin;
    uint8_t _csPin;

    SPISettings _spiSettings;

public:
    /**
     * SPI Communication Constructor
     *
     * @param busy  BUSY pin from VFD
     * @param reset RESET pin from VFD
     * @param cs    Chip Select pin
     */
    GUD900_Serial_SPI(uint8_t busy, uint8_t reset, uint8_t cs)
        : _busyPin(busy),
          _resetPin(reset),
          _csPin(cs),
          _spiSettings(100000, MSBFIRST, SPI_MODE0) // 2 MHz, adjust if needed
    {
    }

    /**
     * Initialize SPI and GPIO
     */
    void init() {
        pinMode(_csPin, OUTPUT);
        pinMode(_resetPin, OUTPUT);
        pinMode(_busyPin, INPUT);

        digitalWrite(_csPin, HIGH);
        digitalWrite(_resetPin, HIGH);

        SPI.begin();
    }

    /**
     * Write one byte to the display
     */
    void write(uint8_t data) {
        while (digitalRead(_busyPin)) {
            yield();
        }

        SPI.beginTransaction(_spiSettings);
        digitalWrite(_csPin, LOW);

        SPI.transfer(DATA_WRITE_CMD);
        SPI.transfer(data);

        digitalWrite(_csPin, HIGH);
        SPI.endTransaction();
    }

    /**
     * Read number of bytes available
     */
    uint8_t statusRead() {
        while (digitalRead(_busyPin)) {
            yield();
        }

        SPI.beginTransaction(_spiSettings);
        digitalWrite(_csPin, LOW);

        SPI.transfer(STATUS_READ_CMD);
        uint8_t value = SPI.transfer(0x00);

        digitalWrite(_csPin, HIGH);
        SPI.endTransaction();

        return value;
    }

    /**
     * Start reading data stream
     */
    void startRead() {
        while (digitalRead(_busyPin)) {
            yield();
        }

        SPI.beginTransaction(_spiSettings);
        digitalWrite(_csPin, LOW);

        SPI.transfer(DATA_READ_CMD);
        // CS remains low until finishRead()
    }

    /**
     * Read one byte
     */
    uint8_t read() {
        return SPI.transfer(0x00);
    }

    /**
     * Finish read operation
     */
    void finishRead() {
        digitalWrite(_csPin, HIGH);
        SPI.endTransaction();
    }

    /**
     * Hardware reset of the module
     */
    void hardReset() {
        init();

        digitalWrite(_csPin, LOW);
        digitalWrite(_resetPin, LOW);
        delay(1);
        digitalWrite(_resetPin, HIGH);
        delay(100);
        digitalWrite(_csPin, HIGH);
    }
};
