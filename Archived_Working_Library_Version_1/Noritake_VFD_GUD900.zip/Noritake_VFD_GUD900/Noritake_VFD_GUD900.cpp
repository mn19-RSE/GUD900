#include "Noritake_VFD_GUD900.h"
#include <Arduino.h>
#include <string.h>
#include <stdio.h>

/* ------------------------------------------------------------
   Internal helpers
------------------------------------------------------------ */

inline void Noritake_VFD_GUD900::command(uint8_t data) {
    if (!io) return;
    io->write(data);
}


void Noritake_VFD_GUD900::us_command(uint8_t group, uint8_t cmd) {
    if (!io) return;
    io->write(0x1F);
    io->write(group);
    io->write(cmd);
}

void Noritake_VFD_GUD900::command(uint8_t prefix, uint8_t group, uint8_t cmd) {
    if (!io) return;
    io->write(prefix);
    io->write(group);
    io->write(cmd);
}

void Noritake_VFD_GUD900::command_xy(unsigned x, unsigned y) {
    command(0x1F, '$', x);
    command(y);
}

void Noritake_VFD_GUD900::command_xy1(unsigned x, unsigned y) {
    command(0x1F, '$', x + 1);
    command(y + 1);
}

void Noritake_VFD_GUD900::crlf() {
    command('\r');
    command('\n');
}

/* ------------------------------------------------------------
   Initialization
------------------------------------------------------------ */

void Noritake_VFD_GUD900::initialState() {
    if (!io) return;
    io->init();
    io->hardReset();
    GUD900_clearScreen();
    GUD900_home();
}

void Noritake_VFD_GUD900::GUD900_init() {
    initialState();
}

void Noritake_VFD_GUD900::GUD900_reset() {
    if (!io) return;
    io->hardReset();
}

/* ------------------------------------------------------------
   Cursor / screen
------------------------------------------------------------ */

void Noritake_VFD_GUD900::GUD900_home() {
    command(0x0B);
}

void Noritake_VFD_GUD900::GUD900_clearScreen() {
    command(0x0C);
}

void Noritake_VFD_GUD900::GUD900_setCursor(unsigned x, unsigned y) {
    command_xy1(x, y);
}

void Noritake_VFD_GUD900::GUD900_carriageReturn() {
    command('\r');
}

void Noritake_VFD_GUD900::GUD900_lineFeed() {
    command('\n');
}

void Noritake_VFD_GUD900::GUD900_back() {
    command(0x08);
}

void Noritake_VFD_GUD900::GUD900_forward() {
    command(0x09);
}

/* ------------------------------------------------------------
   Cursor visibility
------------------------------------------------------------ */

void Noritake_VFD_GUD900::GUD900_cursorOn() {
    us_command('C', 1);
}

void Noritake_VFD_GUD900::GUD900_cursorOff() {
    us_command('C', 0);
}

/* ------------------------------------------------------------
   Display control
------------------------------------------------------------ */

void Noritake_VFD_GUD900::GUD900_displayOn() {
    us_command('D', 1);
}

void Noritake_VFD_GUD900::GUD900_displayOff() {
    us_command('D', 0);
}

void Noritake_VFD_GUD900::GUD900_invertOn() {
    us_command('I', 1);
}

void Noritake_VFD_GUD900::GUD900_invertOff() {
    us_command('I', 0);
}

/* ------------------------------------------------------------
   Scroll / composition
------------------------------------------------------------ */

void Noritake_VFD_GUD900::GUD900_setScrollMode(ScrollMode mode) {
    us_command('S', static_cast<uint8_t>(mode));
}

void Noritake_VFD_GUD900::GUD900_setCompositionMode(CompositionMode mode) {
    us_command('M', static_cast<uint8_t>(mode));
}

/* ------------------------------------------------------------
   Brightness / wait
------------------------------------------------------------ */

void Noritake_VFD_GUD900::GUD900_setScreenBrightness(unsigned level) {
    us_command('B', level);
}

void Noritake_VFD_GUD900::GUD900_wait(uint8_t time) {
    delay(time);
}

/* ------------------------------------------------------------
   Printing
------------------------------------------------------------ */

void Noritake_VFD_GUD900::print(char c) {
    if (!io) return;
    io->write(c);
}

void Noritake_VFD_GUD900::print(const char *str) {
    if (!io || !str) return;
    while (*str) {
        io->write(*str++);
    }
}

void Noritake_VFD_GUD900::print(const char *buffer, size_t size) {
    if (!io || !buffer) return;
    for (size_t i = 0; i < size; i++) {
        io->write(buffer[i]);
    }
}

void Noritake_VFD_GUD900::println(char c) {
    print(c);
    crlf();
}

void Noritake_VFD_GUD900::println(const char *str) {
    print(str);
    crlf();
}

/* ------------------------------------------------------------
   Number printing (portable)
------------------------------------------------------------ */

void Noritake_VFD_GUD900::printNumber(unsigned long number, uint8_t base) {
    char buf[32];
    snprintf(buf, sizeof(buf),
             (base == 10) ? "%lu" :
             (base == 16) ? "%lx" :
             (base == 8)  ? "%lo" : "%lu",
             number);
    print(buf);
}

void Noritake_VFD_GUD900::print(int number, uint8_t base) {
    printNumber(number, base);
}

void Noritake_VFD_GUD900::print(unsigned number, uint8_t base) {
    printNumber(number, base);
}

void Noritake_VFD_GUD900::print(long number, uint8_t base) {
    printNumber(number, base);
}

void Noritake_VFD_GUD900::print(unsigned long number, uint8_t base) {
    printNumber(number, base);
}

void Noritake_VFD_GUD900::println(int number, uint8_t base) {
    print(number, base);
    crlf();
}

void Noritake_VFD_GUD900::println(unsigned number, uint8_t base) {
    print(number, base);
    crlf();
}

void Noritake_VFD_GUD900::println(long number, uint8_t base) {
    print(number, base);
    crlf();
}

void Noritake_VFD_GUD900::println(unsigned long number, uint8_t base) {
    print(number, base);
    crlf();
}

/* ------------------------------------------------------------
   Basic graphics (SPI-safe)
------------------------------------------------------------ */

void Noritake_VFD_GUD900::GUD900_fillRect(
    unsigned x0, unsigned y0,
    unsigned x1, unsigned y1,
    bool on
) {
    for (unsigned y = y0; y <= y1; y++) {
        for (unsigned x = x0; x <= x1; x++) {
            command_xy(x, y);
            command(on ? 0xFF : 0x00);
        }
    }
}
