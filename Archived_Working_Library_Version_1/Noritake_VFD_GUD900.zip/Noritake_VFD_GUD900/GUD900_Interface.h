#pragma once

#include <Arduino.h>
#include <stddef.h>

/**
 * Abstract interface for GUD900 communication backends.
 * SPI-only implementation is currently supported.
 */
class GUD900_Interface {
public:
    virtual ~GUD900_Interface() {}

    // Initialize the interface (SPI, pins, etc.)
    virtual void init() = 0;

    // Write one byte to the display
    virtual void write(uint8_t data) = 0;

    // Reset the display module
    virtual void hardReset() = 0;
};
