#ifndef NORITAKE_VFD_GUD900_H
#define NORITAKE_VFD_GUD900_H

#include <Arduino.h>
#include <stdint.h>
#include <stddef.h>
#include <ctype.h>

#include "GUD900_Interface.h"

/**
 * The available image memory areas.
 */
enum ImageMemoryArea {
    FlashImageArea  = 1,
    ScreenImageArea = 2
};

/**
 * The available scroll modes.
 */
enum ScrollMode {
    WrappingMode    = 1,
    VertScrollMode  = 2,
    HorizScrollMode = 3
};

/**
 * The available composition modes.
 */
enum CompositionMode {
    NormalCompositionMode = 0,
    OrCompositionMode     = 1,
    AndCompositionMode    = 2,
    XorCompositionMode    = 3
};

/**
 * The available screensavers.
 */
enum ScreenSaver {
    AllDotsOffSaver = 2,
    AllDotsOnSaver  = 3,
    InvertSaver     = 4
};

/**
 * The available LED backlight colors.
 * NOTE: Only for specific display models.
 */
enum LEDColor {
    NoLight       = 0x000,
    BlueLight     = 0x00f,
    GreenLight    = 0x0f0,
    CyanLight     = 0x0ff,
    RedLight      = 0xf00,
    MagentaLight  = 0xf0f,
    SmokeLight    = 0xfff
};

/**
 * The available font formats.
 */
enum FontFormat {
    GUD9005x7Format = 0,
    GUD9007x8Format = 1,
    CUUFormat       = 2,
    LCDFormat       = CUUFormat
};

class Noritake_VFD_GUD900 {

private:
    void initialState();
    void printNumber(unsigned long number, uint8_t base);
    void printNumber(unsigned x, unsigned y, unsigned long number, uint8_t base);
    void command(uint8_t data);
    void us_command(uint8_t group, uint8_t cmd);
    void command(uint8_t prefix, uint8_t group, uint8_t cmd);
    void command_xy(unsigned x, unsigned y);
    void command_xy1(unsigned x, unsigned y);
    void crlf();

    GUD900_Interface *io = nullptr;

public:
    uint8_t width;
    uint8_t height;
    uint8_t lines;
    unsigned modelClass;
    bool generation;

    /**
     * Default constructor.
     */
    Noritake_VFD_GUD900() {
        modelClass = 900;
        generation = false;
    }

    /**
     * Attach communication interface.
     */
    void interface(GUD900_Interface &interface) {
        io = &interface;
    }

    /**
     * Initialize display geometry.
     */
    void begin(uint8_t width, uint8_t height) {
        this->width  = width;
        this->height = height;
        this->lines  = height / 8;
    }

    /**
     * Set model class.
     */
    void isModelClass(unsigned modelClass) {
        this->modelClass = modelClass;
    }

    /**
     * Set generation flag.
     */
    void isGeneration(char c) {
        this->generation = (toupper((unsigned char)c) == 'S');
    }

    // --- Command API ---
    void GUD900_back();
    void GUD900_forward();
    void GUD900_lineFeed();
    void GUD900_home();
    void GUD900_carriageReturn();
    void GUD900_setCursor(unsigned x, unsigned y);
    void GUD900_clearScreen();
    void GUD900_cursorOn();
    void GUD900_cursorOff();
    void GUD900_init();
    void GUD900_reset();
    void GUD900_useMultibyteChars(bool enable);
    void GUD900_setMultibyteCharset(uint8_t code);
    void GUD900_useCustomChars(bool enable);
    void GUD900_defineCustomChar(uint8_t code, FontFormat format, const uint8_t *data);
    void GUD900_deleteCustomChar(uint8_t code);
    void GUD900_setAsciiVariant(uint8_t code);
    void GUD900_setCharset(uint8_t code);
    void GUD900_setScrollMode(ScrollMode mode);
    void GUD900_setHorizScrollSpeed(uint8_t speed);
    void GUD900_invertOn();
    void GUD900_invertOff();
    void GUD900_setCompositionMode(CompositionMode mode);
    void GUD900_setScreenBrightness(unsigned level);
    void GUD900_wait(uint8_t time);
    void GUD900_scrollScreen(unsigned x, unsigned y, unsigned count, uint8_t speed);
    void GUD900_blinkScreen();
    void GUD900_blinkScreen(bool enable, bool reverse, uint8_t on, uint8_t off, uint8_t times);
    void GUD900_displayOn();
    void GUD900_displayOff();
    void GUD900_screenSaver(ScreenSaver mode);
    void GUD900_drawImage(unsigned width, uint8_t height, const uint8_t *data);
    void GUD900_setFROMImage(unsigned long address, unsigned long length, const uint8_t *data);
    void GUD900_drawFROMImage(unsigned long address, uint8_t srcHeight, unsigned width, uint8_t height);
    void GUD900_setFontStyle(bool proportional, bool evenSpacing);
    void GUD900_setFontSize(uint8_t x, uint8_t y, bool tall);
    void GUD900_selectWindow(uint8_t window);
    void GUD900_defineWindow(uint8_t window, unsigned x, unsigned y, unsigned width, unsigned height);
    void GUD900_deleteWindow(uint8_t window);
    void GUD900_joinScreens();
    void GUD900_separateScreens();
    void GUD900_setBacklightColor(uint8_t r, uint8_t g, uint8_t b);
    void GUD900_setBacklightColor(unsigned rgb);

    // Print functions
    void print(char c);
    void print(const char *str);
    void print(const char *buffer, size_t size);
    void print(int number, uint8_t base);
    void print(unsigned number, uint8_t base);
    void print(long number, uint8_t base);
    void print(unsigned long number, uint8_t base);
    void println(char c);
    void println(const char *str);
    void println(const char *buffer, size_t size);
    void println(int number, uint8_t base);
    void println(unsigned number, uint8_t base);
    void println(long number, uint8_t base);
    void println(unsigned long number, uint8_t base);

    void GUD900_fillRect(unsigned x0, unsigned y0, unsigned x1, unsigned y1, bool on = true);
};

#endif
